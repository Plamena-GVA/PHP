<?php
//pour pouvoir utiliser la classe Produit depuis ce fichier :
require_once "Produit.php";
require_once "ListeCourses.php";

//on instancie des objets de classe Produit
$produit1 = new Produit("Pain", 2, 0.7);
$produit2 = new Produit("Lait", 6, 0.5);
$produit3 = new Produit("Moutarde", 1, 1);
//tableau d'objets
$tableauProduits = array($produit1, $produit2, $produit3);
//et on teste leurs fonctions
echo $produit1->toString();
echo "\n";
echo $produit1->calculPrixTotal();
echo "\n";
echo $produit2->toString();
echo "\n";
echo $produit2->calculPrixTotal();
echo "\n";
echo $produit3->toString();
echo "\n";
echo $produit3->calculPrixTotal();
var_dump($tableauProduits);
//calcul brut de décoffrage
echo $produit1->calculPrixTotal() + $produit2->calculPrixTotal() + $produit3->calculPrixTotal() . "€\n";
//le même avec une boucle
$prixTotal = 0;
foreach($tableauProduits as $produit){
	$prixTotal += $produit->calculPrixTotal();
}
echo $prixTotal . "€\n";

//maintenant, on va faire un objet liste de courses !
$maListe = new ListeCourses("Auchan", $tableauProduits, $prixTotal);
var_dump($maListe);
$produit4 = new Produit("Lait",4,0.5);
echo $produit4->toString();
echo "\n";
$produit5 = new Produit("Cornichons",1,1.5);
echo $produit5->toString();
echo "\n";
//on teste les ajouts de produit
$maListe->ajouterProduit($produit4);
$maListe->ajouterProduit($produit5);
var_dump($maListe);
$maListe->calculPrixTotal();
echo $maListe->prixTotal;
//test du toString de la liste
echo $maListe->toString();