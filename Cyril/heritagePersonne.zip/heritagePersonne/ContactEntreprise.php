<?php
class ContactEntreprise extends Personne{
	protected $numeroSiret;
	protected $adressePhysique;
	
	function __construct($nomCE, $prenomCE, $ageCE, $telCE, $numSiret, $adrPhys){
		parent::__construct($nomCE, $prenomCE, $ageCE, $telCE);
		$this->numeroSiret = $numSiret;
		$this->adressePhysique = $adrPhys;
	}
	
	public function getNumeroSiret(){
		return $this->numeroSiret;
	}
	
	public function setNumeroSiret($nouveauNumeroSiret){
		$this->numeroSiret = $nouveauNumeroSiret;
	}
	
	public function getAdressePhysique(){
		return $this->adressePhysique;
	}
	
	public function setAdressePhysique($nouvelleAdressePhysique){
		$this->adressePhysique = $nouvelleAdressePhysique;
	}
	
	public function toString(){
		return parent::toString() . "Numero SIRET : " . $this->numeroSiret . "\nAdressePhysique : " . $this->adressePhysique . "\n";
	}
}