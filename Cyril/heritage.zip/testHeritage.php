<?php
require_once "Personne.php";
require_once "User.php";

$userJohn = new User("Amselem", "Jonathan", 28, "05859595959", "j.amselem@ics-nice.com", "pass");
var_dump($userJohn);
echo $userJohn->toString();

$personneCyril = new Personne();
//attention : l'enfant peut utiliser les méthodes du parent, mais pas l'inverse !
//echo $personneCyril->getEmail(); //fatal error