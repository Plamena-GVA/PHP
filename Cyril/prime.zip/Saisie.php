<?php
//on inclut les fichiers pour charger les classes dont on va avoir besoin
require_once "Employe.php";
require_once "Technicien.php";

//classe conteneur qui gère mon programme principal
//classe final : ne sera JAMAIS classe parent, fin de cet arbre d'héritage
final class Saisie{

	//on initialise un tableau d'employés/techniciens
	private $tabEmployes = array();
	
	function getTabEmployes(){
		return $this->tabEmployes;
	}
	
	//pas de setter : on est pas censés réécrire entièrement le tableau des employés !

	function boucleSaisie(){
		//on boucle tant qu'on veut créer des employés/techniciens
		do{
			echo "Bienvenue sur gestion_PHP_Console !\n";
			echo "Voulez-vous entrer un Employé, un Technicien, augmenter quelqu'un(ou tout le monde), afficher la Liste ou Stopper les saisies ?\n";
			$ordre = strtoupper(readline("eE/tT/aA/lL/sS"));
			echo $ordre ."\n";
			switch($ordre){
				case "E":
					//on saisit et crée un employé dans le tableau
					$tabEmp = $this->saisirEmploye();
					$this->tabEmployes[] = new Employe($tabEmp[0], $tabEmp[1], $tabEmp[2], $tabEmp[3]);
					
					break;
				case "T":
					//on saisit et crée un technicien dans le tableau
					$tabTec = $this->saisirTechnicien();
					$this->tabEmployes[] = new Technicien($tabTec[0], $tabTec[1], $tabTec[2], $tabTec[3], $tabTec[4]);
					break;
				case "A":
					$this->augmentationEmployes();
					break;
				case "L":
					$this->afficherTableauEmployes();
					break;
				case "S":
					//on va sortir
					break;
				default:
					//erreur de saisie : on recommence
					echo "Commande inconnue\n";
			}
			
		}while($ordre != "S");
	}
	
	//fonctions gérant la saisie
	function saisirEmploye(){
		$nom = readline("Entrez un nom\n");
		$age = readline("Entrez l'age\n");
		$salaire = readline("Entrez le salaire initial\n");
		$secu = readline("Entrez le numéro de sécurité sociale\n");
		return array($nom, $age, $salaire, $secu);
		
	}

	function saisirTechnicien(){
		$tabTech = $this->saisirEmploye();
		$grade = readline("Entrez le grade du technicien\n");
		array_push($tabTech, $grade);
		return $tabTech;
	}

	//affichage de tout le tableau : boucle sur l'affichage de l'employé individuel
	function afficherTableauEmployes(){
		foreach($this->tabEmployes as $valeur){
			$valeur->afficher();
		}
	}

	//gestion des augmentations d'employé
	function augmentationEmployes(){
		$nomE = readline("Entrez le nom de l'employé à augmenter, ou rien pour une augmentation collective\n");
		$aug = readline("Entrez le montant de l'augmentation\n");
		foreach($this->tabEmployes as $employe){
			//si le nom de l'employé est trouvé OU que le nom entré est une chaîne vide, on augmente de la valeur donnée
			if($nomE == "" || $employe->getNom() == $nomE){
				$employe->augmentation($aug);
				$employe->afficher();
			}
		}
	}
	
}
