<?php
require_once "Saisie.php";

//lancement du programme en dehors de la classe
$saisie = new Saisie();
$saisie->boucleSaisie();