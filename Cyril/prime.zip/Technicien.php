<?php

require_once "Employe.php";
	
	//un Technicien est un Employe étendu
	//même principe avec des cas particuliers
	class Technicien extends Employe{
		//un technicien a un grade, pas les autres employés
		
		//protected me permet d'anticiper : si j'ai besoin plus tard de Technicien spécialistes (ex : Plombier, Electricien...) je pourrai récupérer la valeur de l'attribut sans retoucher au code du Technicien
		protected $grade;
		
		//constructeur de Technicien : appelle le constructeur d'Employe afin de ne pas tout recoder
		function __construct($name, $age, $pay, $nsec, $gradeTec){
			parent::__construct($name, $age, $pay, $nsec);
			$this->grade = $gradeTec;
		}
		
		function getGrade(){
			return $this->grade;
		}
	
		function setGrade($g){
			$this->grade = $g;
		}
		
		
		//fonction pour obtenir la prime dépendant du grade
		function prime(){
			switch($this->grade){
				case "A":
					return 300;
				case "B":
					return 200;
				case "C":
					return 100;
				//si le grade n'est pas prévu pas de prime
				default :
					return 0;
			}
		}
		
		//on passe par le toString de l'employé pour les attributs qui étaient déjà là
		function toString(){
			return parent::toString() . "Grade : " . $this->grade . "\n";
		}
		
		//le salaire effectif du technicien, incluant sa prime
		function calculeSalaire(){
			return parent::calculeSalaire() + $this->prime();
		}
	}
?>