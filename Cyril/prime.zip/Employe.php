<?php
//la classe Employe représente un employé de la structure
class Employe{
	//les attributs de mes Employe
	//protected permet à ma classe enfant Technicien d'accéder aux attributs
	protected $nom;
	protected $age;
	protected $salaire;
	protected $secu;
	
	function __construct($name, $age, $pay, $nsec){
		$this->nom = $name;
		$this->age = $age;
		$this->salaire = $pay;
		$this->secu = $nsec;
	}
	
	//getters et setters des attributs de la classe
	function getNom(){
		return $this->nom;
	}
	
	function setNom($n){
		$this->nom = $n;
	}
	
	function getAge(){
		return $this->age;
	}
	
	function setAge($a){
		$this->age = $a;
	}
	
	function getSalaire(){
		return $this->salaire;
	}
	
	function setSalaire($sa){
		$this->salaire = $sa;
	}
	
	function getSecu(){
		return $this->secu;
	}
	
	function setSecu($se){
		$this->secu = $se;
	}
	
	//on augmente le salaire suivant l'augmentation
	function augmentation($augment){
		$this->salaire += $augment;
	}
	
	//fonction toString : convertir le contenu de mon objet en String
	public function toString(){
		return "Nom : " . $this->nom . "\nAge : " . $this->age . "\nSalaire : " . $this->salaire ."\nNuméro Sécurité Sociale : " . $this->secu . "\nSon salaire effectif est de " . $this->calculeSalaire() . "\n";
	}
	
	//affiche la représentation String de l'objet
	public function afficher(){
		echo $this->toString();
	}
	
	public function calculeSalaire(){
		return $this->salaire;
	}
	
}
?>